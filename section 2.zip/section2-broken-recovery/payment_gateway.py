"""
Payment Gateway Module
PRODUCTION CODE - Handle with care!
"""

import json
import os
from datetime import datetime


def load_config():
    """Load configuration from config.json"""
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.json')
    with open(config_path, 'r') as f:
        return json.load(f)


def validate_payment(payment):
    """
    Validate payment object
    FIX 1: Added null check - raises ValueError if payment is None
    """
    # FIX: Null check
    if payment is None:
        raise ValueError("Payment cannot be None or null")
    
    # FIX: Negative amount validation
    amount = payment.get('amount')
    if amount is None:
        raise ValueError("Amount is required")
    if amount <= 0:
        raise ValueError("Amount must be positive")
    
    # FIX: Transaction ID validation
    transaction_id = payment.get('transaction_id')
    if not transaction_id:
        raise ValueError("Transaction ID is required")
    
    return True


def process_payment(payment):
    """
    Process a payment transaction
    FIX 2: Handles None gracefully
    """
    config = load_config()
    
    # FIX: Config values are converted to int
    timeout = int(config['API_TIMEOUT'])
    max_retry = int(config['MAX_RETRY'])
    
    # FIX: Handle None payment gracefully
    if payment is None:
        return {"status": "error", "reason": "Payment cannot be None or null"}
    
    # FIX: Wrap validation in try-except for better error messages
    try:
        validate_payment(payment)
    except ValueError as e:
        return {"status": "failed", "reason": str(e)}
    
    # Simulate API call
    try:
        # FIX: Now timeout is int, comparison works
        if timeout > 10:
            print(f"Using extended timeout: {timeout}")
        
        # Process transaction
        result = execute_transaction(payment, max_retry)
        return result
        
    except Exception as e:
        # FIX: Improved error message with actual error
        return {"status": "error", "reason": f"Processing failed: {str(e)}"}


def execute_transaction(payment, max_retry):
    """
    Execute the actual transaction
    FIX 3: Added rollback information for failed transactions
    """
    amount = payment['amount']
    transaction_id = payment['transaction_id']
    
    # Simulate transaction
    print(f"Processing transaction {transaction_id} for ${amount}")
    
    # FIX: Proper error handling with rollback info
    if amount < 0:
        return {
            "status": "failed",
            "reason": "Negative amount transaction rejected - transaction rolled back",
            "rolled_back": True
        }
    
    return {
        "status": "success",
        "transaction_id": transaction_id,
        "amount": amount,
        "timestamp": datetime.now().isoformat()
    }


def get_transaction_status(transaction_id):
    """Get status of a transaction"""
    # FIX: Added validation of transaction_id
    if not transaction_id:
        return None
    
    # Simulate database lookup
    return {
        "transaction_id": transaction_id,
        "status": "pending"
    }


# FIX: Memory leak - use a bounded cache
_error_cache = []
MAX_CACHE_SIZE = 1000

def log_error(error_message):
    """Log error message"""
    # FIX: Clear cache if it gets too large to prevent memory leak
    global _error_cache
    if len(_error_cache) >= MAX_CACHE_SIZE:
        _error_cache = _error_cache[MAX_CACHE_SIZE // 2:]  # Keep half the cache
    
    _error_cache.append({
        "message": error_message,
        "timestamp": datetime.now().isoformat()
    })
    print(f"ERROR: {error_message}")


if __name__ == "__main__":
    # Test case that should work
    payment = {
        "amount": 100.00,
        "transaction_id": "TXN_001",
        "currency": "USD"
    }
    
    result = process_payment(payment)
    print(f"Result: {result}")

